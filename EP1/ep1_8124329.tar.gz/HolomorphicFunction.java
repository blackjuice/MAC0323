public interface HolomorphicFunction {
    public Complex eval(Complex x);
    public Complex diff(Complex x);
}

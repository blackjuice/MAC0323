/*************************************************************************
 *  nome:   LUCAS SUNG JUN HONG
 *  n.USP:  812 432 9
 *
 *  EP1 - MAC 0323 - 2015
 *
 *  Dependencies: Picture.java Newton.java
 *  
 *  Cria-se um quadro M por N em que cada pixel é definido pela intensidade da cor vermelha.
 *  Sorteamos cores iniciais r , g , b. Por motivos estéticos, (r) varia [100..255]
 *  e (g) e (b) variam [1..200]
 *
 *  Quando o numero de iteracoes (N) for maior ou igual a (maxI), definido pelo usuario,
 *  a regiao tem cor VERMELHA (255,0,0). Caso contrario, dependendo do "peso" de (N),
 *  a intensidade dessa cor varia.
 *
 *  Ou seja, caso (N) tiver valor muito menor que (maxI), a regiao (o pixel) tera um cor mais
 *  escurecida. Um (N) proximo ao (maxI) tem a regiao com uma cor mais clara.
 *
 *
 *************************************************************************/

import java.awt.Color;
import java.util.Random;

public class NewtonBasins {

    public static void draw(HolomorphicFunction f, int maxI, 
                            double x, double y, double xsize, double ysize,
                            int M, int N) {
        Picture pic = new Picture(M, N);
        Random randomGenerator = new Random();
        int r = randomGenerator.nextInt(255 - 100) + 100; //r(red) sera sorteada no intervalo [100..255]
        int g = randomGenerator.nextInt(200 - 1) + 1;     //g(green) sera sorteada no intervalo [1..200]
        int b = randomGenerator.nextInt(200 - 1) + 1;     //b(blue) sera sorteada no intervalo [1..200]

        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {

                Counter count = new Counter("count"); // inicializa counter
                double xc = ( x - xsize / 2 ) + i * ( (x + xsize / 2) / M );
                double yc = ( y - ysize / 2 ) + j * ( (y + ysize / 2) / N );

                // inicializamos z0
                Complex z0 = new Complex(xc, yc);
                Complex z = Newton.findRoot(f, z0, count);

                // inicializamos color e sorteamos r, g, b
                Color color = new Color(255, 255, 255);

                // diferenca entre maxI e Counter N
                int df = maxI - count.tally();

                // Caso a diferenca seja menor ou igual a 0, teremos a cor VERMELHA, cc teremos uma outra cor
                if (df > 0)
                    color = new Color( r - (df % r ), g - (df % g), b - (df % b) );
                else
                    color = new Color(255, 0, 0);

                // posicao 0,0 sera o canto superior esquerdo
                pic.set(i, N-1-j, color);
            }
        }
        pic.show();
    }
}
/*************************************************************************
 *  nome:   LUCAS SUNG JUN HONG
 *  n.USP:  812 432 9
 *
 *  EP1 - MAC 0323 - 2015
 *
 *  imagens geradas estao em http://www.linux.ime.usp.br/~lucassjhong
 *  Figura 2 - 25 0.5 0 3 3 700 700
 *  Figura 3 - 50 0.5 0 3 3 700 700
 *  Figura 4 - 75 0.5 0 3 3 700 700
 *  Figura 5 - 100 0.5 0 3 3 700 700
 *
 *  Aqui aplicamos: f(x) = x^4 - c
 *************************************************************************/

public class FourthRoots {
    
    public static void main(String[] args) {
    
        int     maxI    = Integer.parseInt(args[0]);
        double  xc      = Double.parseDouble(args[1]);
        double  yc      = Double.parseDouble(args[2]);
        double  xsize   = Double.parseDouble(args[3]);
        double  ysize   = Double.parseDouble(args[4]);
        int     M       = Integer.parseInt(args[5]);
        int     N       = Integer.parseInt(args[6]);

        Complex[] r = new Complex[4];

        r[0] = new Complex( 1, 0); r[1] = new Complex(-1, 0);
        r[2] = new Complex( 0, 1); r[3] = new Complex( 0, -1);
    
        HolomorphicFunction f = new Poly(r);
        NewtonBasins.draw(f, maxI, xc, yc, xsize, ysize, M, N);
    }
}

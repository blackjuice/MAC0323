/*************************************************************************
 *  nome:   LUCAS SUNG JUN HONG
 *  n.USP:  812 432 9
 *
 *  EP1 - MAC 0323 - 2015
 *
 *  Dependencies: Complex.java Counter.java
 *  
 *  Calculo de f(z) = 0 pelo Metodo de Newton, tomando z0 como inicio.
 *  Consideramos eps (Epsilon) = 1e-15 = 0.000000000000001 + 0*i
 *
 *************************************************************************/

public class Newton {

    public static Complex findRoot(HolomorphicFunction f, Complex z0, Counter N) {
        Complex     eps     = new Complex(1e-15, 0.0);//eps = 0.000000000000001
        Complex     z       = z0;
        Complex     delta   = f.eval(z).divides(f.diff(z)); // f.eval(z) / f.diff(z)
        Complex     zero    = new Complex(0.0, 0.0);

        /* Enquanto: N < 50000
         *     aplicamos Metodo de Newton: z_n = z_n-1 - delta
         *     tal que delta = f.eval(z_n-1) / f.diff(z_n-1)
         *     O programa tem break quando obtivemos uma boa aproximacao: |delta| <= |eps / z|
         */
        while ( N.tally() < 50000 ) {
           z        = z.minus(delta);
           delta    = f.eval(z).divides(f.diff(z));

           N.increment(); // incrementamos N
           if (delta.abs() <= (eps.divides(z)).abs()) break;
        }
        return z;

    }
}
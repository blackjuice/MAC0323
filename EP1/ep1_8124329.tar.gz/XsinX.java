/*************************************************************************
 *  nome:   LUCAS SUNG JUN HONG
 *  n.USP:  812 432 9
 *
 *  EP1 - MAC 0323 - 2015
 *
 *  imagens geradas estao em http://www.linux.ime.usp.br/~lucassjhong
 *  Figura 7 - 15 -0.25 0.5 3 3 300 300 3 1
 *  Figura 8 - 20 -0.25 0.5 3 3 500 500 2 0
 *
 *  Aqui aplicamos: f(x) = cos(x*2pi) * sin(x*2pi) - c
 *************************************************************************/

public class XsinX {
    
    public static void main(String[] args) {
        
        int     maxI = Integer.parseInt(args[0]);
        double  xc = Double.parseDouble(args[1]);
        double  yc = Double.parseDouble(args[2]);
        double  xsize = Double.parseDouble(args[3]);
        double  ysize = Double.parseDouble(args[4]);
        int     M = Integer.parseInt(args[5]);
        int     N = Integer.parseInt(args[6]);
        double  a = StdIn.readDouble();
        double  b = StdIn.readDouble();

        HolomorphicFunction f = new XsinXfn(new Complex(a, b));

        NewtonBasins.draw(f, maxI, xc, yc, xsize, ysize, M, N);
    }
}
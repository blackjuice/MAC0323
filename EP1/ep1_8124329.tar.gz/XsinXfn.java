public class XsinXfn implements HolomorphicFunction {

    private Complex c;

    public XsinXfn(Complex c) { this.c = c; }

    // returns f(x) = cos(2\pi x)sin(2\pi x) - c = cos(x*2pi) * sin(x*2pi) - c
    public Complex eval(Complex x) {    
        return x.times(2*3.1415926535897932385).cos().times(x.times(2*3.1415926535897932385).sin()).minus(c);
    }
    // returns f’(x) = 2\pi cos(4\pi x)
    public Complex diff(Complex x) {
        return x.times(4*3.1415926535897932385).cos().times(2*3.1415926535897932385);
    }
}